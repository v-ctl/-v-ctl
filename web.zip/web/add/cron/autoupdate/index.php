<?php include($_SERVER['DOCUMENT_ROOT'].'/static/index.html'); ?>
